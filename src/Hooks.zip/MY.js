import React from 'react';

// Default export
function MY() {
  return <h2>Hello from MyComponent!</h2>;
}

export default MY;  // Default export
