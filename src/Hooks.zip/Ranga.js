import React from 'react';



function Ranga() {
  return( <h1>Hello, World!</h1>);
}

export default Ranga;
